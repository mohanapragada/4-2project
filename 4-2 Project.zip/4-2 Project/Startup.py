import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
import warnings  # Ignores any warning
warnings.filterwarnings("ignore")
app = Flask(__name__)
model = pickle.load(open('form.pkl', 'rb'))

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/data')
def data():
    return render_template('data.html')


@app.route('/predict',methods=['POST'])
def predict():
    '''
    For rendering results on HTML GUI
    '''
    i_f = []
    gender=request.form['gen']
    i_f.append(int(gender))
    marriage=request.form['marry']
    i_f.append(int(marriage))
    depends=request.form['depen']
    i_f.append(int(depends))
    education=request.form['edu']
    i_f.append(int(education))
    self_e=request.form['se']
    i_f.append(int(self_e))
    ai=request.form['ai']
    i_f.append(int(ai))
    ci=request.form['ci']
    i_f.append(int(ci))
    la=request.form['la']
    i_f.append(int(la))
    lat=request.form['lat']
    i_f.append(int(lat))
    ch=request.form['ch']
    i_f.append(int(ch))
    pa=request.form['pa']
    i_f.append(int(pa))
    final = [np.array(i_f)]
    prediction = model.predict(final)
    output = int(prediction)
    print(output)
    if int(output) is 0:
        return render_template('data.html',prediction_output='You are not eligible to take the loan')
    elif int(output) is 1:
        return render_template('data.html',prediction_output='You are eligible to take the loan')
    
    
    

if __name__=="__main__":
    app.run(debug=True)
