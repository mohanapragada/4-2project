import numpy as np
import pandas as pd
import seaborn as sns
sns.set(style='darkgrid')
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier  
url =r"C:\Users\mohana lakshmi\Desktop\4-2 Project\loan_prediction.csv"
df = pd.read_csv(url)
print(df)
print(df.dtypes)
df['Gender'] = df['Gender'].map({'Male':1,'Female':0})
df['Married'] = df['Married'].map({'Yes':1,'No':0})
df['Education'] = df['Education'].map({'Graduate':1,'Not Graduate':0})
df['Self_Employed'] = df['Self_Employed'].map({'Yes':1,'No':0})
df['Property_Area'] = df['Property_Area'].map({'Urban':1,'Rural':2,'Semiurban':3})
df['Loan_Status'] = df['Loan_Status'].map({'Y':1,'N':0})
df=df.dropna(axis=0)
X= df.iloc[:,0:12].values
print(X)
Y= df.iloc[:, 1].values
print(Y)
x_train, x_test, y_train, y_test= train_test_split(X, Y, test_size= 0.2, random_state=0)
#fitting ramdomforest classifier  to the traning set
classifier= RandomForestClassifier(n_estimators= 10, criterion="entropy",random_state=0)  
classifier.fit(x_train, y_train)  
a=classifier.score(x_test,y_test)
print(a*100)
#Fitting Decision Tree classifier to the training set  
classifier= DecisionTreeClassifier(criterion='entropy', random_state=0)  
classifier.fit(x_train, y_train)  
b=classifier.score(x_test,y_test)
print(b*100)
#Fitting knn algorithm classifier to the training set
classifier= KNeighborsClassifier(n_neighbors=5, metric='minkowski', p=2 )  
classifier.fit(x_train, y_train)
classifier.fit(x_train, y_train)  
c=classifier.score(x_test,y_test)
print(c*100)
from sklearn.linear_model import LogisticRegression  
classifier= LogisticRegression(random_state=0)  
classifier.fit(x_train, y_train) 
d=classifier.score(x_test,y_test)
print(d*100)
# Fitting Naive Bayes to the Training set  
from sklearn.naive_bayes import GaussianNB  
classifier = GaussianNB()  
classifier.fit(x_train, y_train)  
classifier.fit(x_train, y_train) 
e=classifier.score(x_test,y_test)
print(e*100)