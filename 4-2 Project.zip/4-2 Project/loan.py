

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import pickle
import warnings
from sklearn.model_selection import train_test_split
warnings.filterwarnings('ignore')

df = pd.read_csv('loan_prediction.csv')
df['Gender'] = df['Gender'].map({'Male':1,'Female':0})
df['Married'] = df['Married'].map({'Yes':1,'No':0})
df['Education'] = df['Education'].map({'Graduate':1,'Not Graduate':0})
df['Self_Employed'] = df['Self_Employed'].map({'Yes':1,'No':0})
df['Property_Area'] = df['Property_Area'].map({'Urban':1,'Rural':2,'Semiurban':3})
df['Loan_Status'] = df['Loan_Status'].map({'Y':1,'N':0})
df=df.dropna(axis=0)


X = df.iloc[:, :-1]
y = df.iloc[:, -1]
X1_train, X1_test, y1_train, y1_test = train_test_split(X, y, test_size=0.2, random_state=0)


#Splitting Training and Test Set
#Since we have a very small dataset, we will train our model with all availabe data.

from sklearn.ensemble import RandomForestClassifier 
regressor=RandomForestClassifier()

#Fitting model with trainig data
regressor.fit(X1_train,y1_train)

# Saving model to disk
pickle.dump(regressor, open('form.pkl','wb'))

# Loading model to compare the results
model = pickle.load(open('form.pkl','rb'))

